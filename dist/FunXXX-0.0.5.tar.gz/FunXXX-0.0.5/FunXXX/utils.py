# -*- coding: utf-8 -*-
"""
Created on Wed Aug 23 10:42:23 2023

@author: NINGMEI
"""

def hello():
    print("hello")